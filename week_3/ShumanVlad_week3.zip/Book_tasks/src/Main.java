
public class Main {
    public static void main(String[] args)
    {
        Task13.ans();
        //Task14.ans();
        Task15.ans();
    }
}