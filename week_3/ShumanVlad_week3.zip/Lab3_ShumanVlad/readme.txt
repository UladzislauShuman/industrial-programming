how to run code

vladlox@vladlox-XPS-13-9370:~/git/industrial-programming/week_3/Lab3_ShumanVlad/src/main/java$ javac org/lab/Main.java org/lab/Matrix.java org/lab/MyException.java
vladlox@vladlox-XPS-13-9370:~/git/industrial-programming/week_3/Lab3_ShumanVlad/src/main/java$ java org.lab.Main ../../../tests/test2.txt
1 10
10 10
Min : 1
Max :
