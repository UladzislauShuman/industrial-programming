public class Main {
    public static void main(String[] args)
    {
        System.out.println(Task1.plus(5,4));
        System.out.println(Task2.amountWordsLatin("One two three раз два три one1 two2 123"));
        System.out.println(Task3.deleteUnnecessary("123 open,. 123da"));
    }
}